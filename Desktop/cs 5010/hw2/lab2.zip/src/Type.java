/**
 * The enum class that includes three types of Gears.
 */
public enum Type {
  HEAD, HAND, FOOT;
}

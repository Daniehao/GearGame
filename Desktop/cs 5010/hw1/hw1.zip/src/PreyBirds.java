import java.util.ArrayList;

public class PreyBirds extends AbstractBirds{
  public PreyBirds() {
    preferredFood = new ArrayList<>();
  }
  @Override
  public void setCharacteristic() {
    this.characteristic = "Having sharp, hooked beaks with visible nostrils.";
  }
}

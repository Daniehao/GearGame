import java.util.ArrayList;

public class Owl extends AbstractBirds{
  public Owl() {
    preferredFood = new ArrayList<>();
  }

  @Override
  public void setCharacteristic() {
    this.characteristic = "Having the facial disks that frame the eyes and bill.";
  }
}
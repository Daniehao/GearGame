import java.util.ArrayList;

public class WaterFowl extends AbstractBirds{
  public WaterFowl() {
    preferredFood = new ArrayList<>();
  }
  @Override
  public void setCharacteristic() {
    this.characteristic = "Living near water sources (fresh or salt).";
  }
}
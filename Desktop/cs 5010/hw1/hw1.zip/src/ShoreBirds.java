import java.util.ArrayList;

public class ShoreBirds extends AbstractBirds{
  public ShoreBirds() {
    preferredFood = new ArrayList<>();
  }

  @Override
  public void setCharacteristic() {
    characteristic = "Having the great auk, horned puffin, and African Jacana.";
  }
}

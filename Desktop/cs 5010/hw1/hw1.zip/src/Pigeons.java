import java.util.ArrayList;

public class Pigeons extends AbstractBirds{
  public Pigeons() {
    preferredFood = new ArrayList<>();
  }

  @Override
  public void setCharacteristic() {
    this.characteristic = "Feeding their young \"bird milk\" very similar to the milk of mammals.";
  }
}
